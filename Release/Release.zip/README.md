# Misc Fixes

- Incompletable void seed bug
- Stage 1 Village PopulateScene exception when spawning drones with the wrong card type when devotion is enabled
- The dreadful Facepunch exception that can occur, which randomly prevented loading (3% bug)
- Fixes an unrecoverable error caused by having multiple event systems (thanks Bubbet)

- Fixed all the new Antler NREs
- Fixed the roulette check nre
- Lunar exploder error
- Equipment indicator error
- TetherVFXOrigin event nre
- CharacterMaster TrueKill error
- FogDamageController nre

- A lot more stuff but i hate writing these so just check the changelog