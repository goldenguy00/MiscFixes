# Misc Fixes

- Incompletable void seed bug
- Stage 1 Village PopulateScene exception when spawning drones with the wrong card type when devotion is enabled
- The dreadful Facepunch exception that can occur, which randomly prevented loading (3% bug)
- Fixes an unrecoverable error caused by having multiple event systems (thanks Bubbet)

- Fixed all the new Antler NREs
- Fixed the roulette check nre
- Lunar exploder error
- Equipment indicator error
- TetherVFXOrigin event nre
- CharacterMaster TrueKill error
- FogDamageController nre

### Mod Specific stuff

- Hunk TVirus death error
- Hunk Urostep error
- Tyranitar King Rock error
- GoldenCoast chest interaction error
- Multiple CelestialWarTank errors
    - Some "minor" optimizations
    - Added optimization cfg setting, try it out!
- Rifter errors